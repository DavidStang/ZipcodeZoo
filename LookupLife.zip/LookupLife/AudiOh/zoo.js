
var Site = {
	init: function(){
                Site.zooStuff();
                Site.fontSettings();
		Site.fontResizer();
		Site.fontChanger();
                Site.getStuff();
                Site.getExplore();
                  
	},



fontChanger:function(){
		//add clicks
		$('changeVerdana').addEvent('click', function() {
			Cookie.set("font-family", "verdana",{path: '/',duration: 90}); 
			$('maindiv').setStyle('font-family','Verdana, Arial, Helvetica, sans-serif');
		});
		$('changeGeneva').addEvent('click', function() {
			Cookie.set("font-family", "geneva", {path: '/',duration: 90}); 
			$('maindiv').setStyle('font-family','Geneva, Arial, Helvetica, sans-serif');
		});
		$('changeGeorgia').addEvent('click', function() {
			Cookie.set("font-family", "georgia", {path: '/',duration: 90}); 
			$('maindiv').setStyle('font-family','Georgia, "Times New Roman", Times, serif');
		});
		//check for a cookie and set the style
		if(Cookie.get("font-family") == "geneva"){
			$('maindiv').setStyle('font-family','Geneva, Arial, Helvetica, sans-serif');
		}else if(Cookie.get("font-family") == "georgia"){
			$('maindiv').setStyle('font-family','Georgia, "Times New Roman", Times, serif');
		}else{
			//do nothing, leave default
		}
	},

fontResizer:function(){
		//resize the font to different pixel values
		 var resize = new Fx.Style('maindiv', 'font-size', {duration: 1000});
		$('fontLarge').addEvent('click', function() {
			resize.start(20);
			Cookie.set("font-size", "large",{path: '/',duration: 90}); 
		});
		$('fontMed').addEvent('click', function() {
			resize.start(12);
			Cookie.set("font-size", "medium" ,{path: '/',duration: 90}); 
		})
		$('fontSmall').addEvent('click', function() {
			resize.start(10);
			Cookie.set("font-size", "small", {path: '/',duration: 90}); 
		})
		//check for font size cookie
		if(Cookie.get("font-size") == "large"){
			resize.set(20);
		}else if(Cookie.get("font-size") == "small"){
			resize.set(10);
		}else{
			//do nothing, leave default
		}
	},




zooStuff:function(){
var myTips = new Tips($$('.toolTipElement'), {
	timeOut: 700,
	maxTitleChars: 50, 
	maxOpacity: .9
});




var imgTips = new Tips($$('.imagetip'), {
        showDelay: 400,
	hideDelay: 200,
        maxTitleChars: 50,
        maxOpacity: .9,
        className: 'custom'
});


var sScroll = new SmoothScroll({duration: 800});


},

getStuff:function(){

$$('a.zoojax ').each(function(item) { // get all anchors inside the element 
	item.addEvent('click', function(e) { 
		new Event(e).stop(); // stop the browser event
		var url = this.getProperty('href'); // get the href 

	 new Ajax (url, { 
                        autoCancel: true,
			method: 'get',
                        update: $('maindiv'),
                        onRequest: 

                             function() {			   
                 $('maindiv').empty().setHTML("<div class='divloader'> <img src='http://www.zipcodezoo.com/gallery/css/img/loading.gif' alt='Loading' /> </div>");
                 
                 
			}, 

                        onComplete: function () {
 Site.zooStuff();
 decoGreyboxLinks();

                        },
                        onFailure: function(){
                       

 $('maindiv').empty().setHTML("<div class='divloader'> Data Loading Failed. </div>");

                        },   
            
                evalScripts: true
		}).request();  
	}.bind(item)); 
});
},



getExplore:function(){
$$('#keepex a').each(function(item) { // get all anchors inside the element 
	item.addEvent('click', function(e) { 
		new Event(e).stop(); // stop the browser event
		var url = this.getProperty('href'); // get the href 
		new Ajax(url, {
                        autoCancel: true,
			method: 'get',
			update: $('maindiv'),
                        onRequest: function(){
				$('maindiv').empty().setHTML("<div class='divloader'> <img src='http://www.zipcodezoo.com/gallery/css/img/loading.gif' alt='Loading' /> </div>");
			}, 
                        onComplete: function () {
             
             newLoadDynamicFeedControl();
             LoadDynamicFeedControl2();
             ngcLoadDynamicFeedControl();
             LoadDynamicFeedControl3();
             LoadSlideShow();
            
      },
      onFailure: function(){
                        $('maindiv').empty().setHTML("<div class='divloader'> Data Loading Failed. </div>");
                        },
      evalScripts: true
		}).request();  
	}.bind(item)); // 
});

},


fontSettings: function() {


var shelf = new Fx.Slide('shelf').hide(); //Create new Fx.Slide object from shelf div, also the hide() function hides the div when the window loads
 $('fontsettings').addEvent('click', function(e) { //Adds an onClick event to header div
    e = new Event(e); 
	shelf.toggle(); //toggles the div	
    if ($('fontsettings').hasClass('arrow-down')){
	 $('fontsettings').removeClass('arrow-down').addClass('arrow-up');
	}
	else {
	 $('fontsettings').removeClass('arrow-up').addClass('arrow-down');
	}
	e.stop(); //this makes sure that the user wont be sent to given url (or that the page refreshes when using dummy url like "#" if the clicked element was a link 
 });


},


formatFootnotes: function(contID,noteID)
{
	// check for DOM capabilities
	if (!document.getElementById)
		return false;
        var articles = 0;
	var cont = document.getElementById(contID);
	var noteholder = document.getElementById(noteID);
	var spans = cont.getElementsByTagName("span");
	
	var notes = 0;
	articles++;
	
	for (i=0;i<spans.length;i++)
	{
		if (spans[i].className == "footnote")
		{
			notes++;
			
			// get content of span
			var noteNode = spans[i].cloneNode( true );
			
			// remove css styling
			noteNode.className = "";
		
			// create a new div to hold the footnote
			var newEle = document.createElement( "div" );
			
			newEle.appendChild( document.createTextNode( notes + ". " ) );
			newEle.appendChild( noteNode );
			
			// add backlink
			blink = document.createElement("a");
			blink.href = "#ftnlink"+articles+"_"+notes;
                        blink.className = "baklink";
			blink.appendChild( document.createTextNode( "[back]" ) );
			newEle.appendChild( blink );
			 
			noteholder.appendChild( newEle );
			
			// add id & style
			noteholder.lastChild.id = "ftn"+articles+"_"+notes;
			noteholder.lastChild.className = "footnote";
			
			
			// insert link into span
			var newEle = document.createElement( "a" );
			newEle.href = "#"+noteID;
			newEle.title = "show footnote";
			newEle.id = "ftnlink"+articles+"_"+notes;
			newEle.className = "ftnlink";
			
			newEle.appendChild( document.createTextNode( notes ) );
			
			// empty span
			while (spans[i].childNodes.length)
				spans[i].removeChild( spans[i].firstChild );
			
			spans[i].appendChild( newEle );
		}
	}
	
}


};
window.addEvent('domready', Site.init);

 