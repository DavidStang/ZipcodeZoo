
var Main = {
	init: function(){
                Main.getMain();
                
                
	},

getMain:function(){

$$('a.mainjax').each(function(item) { // get all anchors inside the element 
	item.addEvent('click', function(e) { 
		new Event(e).stop(); // stop the browser event
		var url = this.getProperty('href'); // get the href 

	 new Ajax (url, { 
                        autoCancel: true,
			method: 'get',
                        update: $('maindivcon'),
                        onRequest: 

                             function() {			   
                 $('maindivcon').empty().setHTML("<div class='divloader'> <img src='http://www.zipcodezoo.com/gallery/css/img/loading.gif' alt='Loading' /> </div>");
                 
                 
			}, 

                        onComplete: function () {
 Site.zooStuff();
 corners();

                        },

                        
                        onFailure: function(){
                       

 $('maindivcon').empty().setHTML("<div class='divloader'> Data Loading Failed. </div>");

                        },   
            
                evalScripts: true
		}).request();  
	}.bind(item)); 
});
}

};
window.addEvent('domready', Main.init);

